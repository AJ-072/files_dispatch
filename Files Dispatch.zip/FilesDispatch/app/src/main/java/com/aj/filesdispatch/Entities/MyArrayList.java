package com.aj.filesdispatch.Entities;

import java.util.ArrayList;

class MyArrayList extends ArrayList<SentFileItem> {

   /* public boolean contains(FileData filePack) {
        while(this.listIterator().hasNext()){
            if(this.listIterator().next().getFileName().equals(filePack.getFileName())){
                return true;
            }
        }
        return false;
    }
    public void cast(ArrayList<FileViewItem> viewItems){
        for (FileViewItem item:viewItems){
            //this.add(((SentFileItem) (FileData) item));
        }
    }*/
}
