package com.aj.filesdispatch.Enums;

public enum Action {ACTION_ADD, ACTION_REMOVE, ACTION_PAUSE, ACTION_STOP, ACTION_RESUME}
