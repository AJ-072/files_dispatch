package com.aj.filesdispatch.Interface;

import com.aj.filesdispatch.Entities.SentFileItem;

public interface setClickListener{
    void onClick(SentFileItem item);
}
