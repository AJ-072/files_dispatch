package com.aj.filesdispatch.Interface;

import com.aj.filesdispatch.Models.SentFileItem;

public interface setClickListener{
    void onClick(SentFileItem item);
}
