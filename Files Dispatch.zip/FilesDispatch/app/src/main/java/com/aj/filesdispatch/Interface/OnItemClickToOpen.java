package com.aj.filesdispatch.Interface;

import com.aj.filesdispatch.Models.FileViewItem;

public interface OnItemClickToOpen {
    void OnClick(FileViewItem item);
}
