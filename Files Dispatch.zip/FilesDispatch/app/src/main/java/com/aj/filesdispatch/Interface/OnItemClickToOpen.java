package com.aj.filesdispatch.Interface;

import com.aj.filesdispatch.Entities.FileItem;

public interface OnItemClickToOpen {
    void OnClick(FileItem item);
}
